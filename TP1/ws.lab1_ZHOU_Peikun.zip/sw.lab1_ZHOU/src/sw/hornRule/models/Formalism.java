package sw.hornRule.models;
 
/**
 * @author
 *
 */
public abstract class Formalism {
	protected String name; // the name of the formalism, such as propositional logic, horn clauses, etc.
	
}
